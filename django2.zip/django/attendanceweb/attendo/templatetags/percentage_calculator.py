from django import template
from attendo.models import Attendance

register=template.Library()

@register.simple_tag
def percalculate(stu_id):
    try:
        total_attendance=Attendance.objects.filter(student_id=stu_id)
        present=Attendance.objects.filter(student_id=stu_id).exclude(status='absent')
        attendance_percentage=len(present)/len(total_attendance) * 100
        return attendance_percentage
    except Exception:
        return None